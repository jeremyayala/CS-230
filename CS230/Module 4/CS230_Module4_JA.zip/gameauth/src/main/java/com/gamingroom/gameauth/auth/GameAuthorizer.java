package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;


import org.checkerframework.checker.nullness.qual.Nullable;

public class GameAuthorizer implements Authorizer<GameUser> 
{
    @Override
    public boolean authorize(GameUser user, String role) {
    	
    	return user.getRoles() != null && user.getRoles().contains(role); // Finishing authorizer 
    }
}