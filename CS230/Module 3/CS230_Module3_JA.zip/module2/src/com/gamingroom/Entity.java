package com.gamingroom;

public class Entity {
	
	// setting attributes from UML to private
	
	private long id ;
	
	private String name;
	
	
	// creating main constructor
	
	private Entity() {
		
	}
	
	// public version of entity
	
	 public Entity(long id, String name) { 
		 
		 //calling the default constructor
		 
		 
		 this();
	     this.id = id;
	     this.name = name;
		 
	 }
	 
	  public long getId() {

	        return id;

	    }

	    public String getName() {

	        return name;

	    }

	    public String toString() {
	    	
	    	// printing the values of all the other methods into one string

	        return "Entity [id = " + id + ", name = " + name + "]";

	    }
	 
}