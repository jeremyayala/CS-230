package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{
	//long id; should now be included in the constructor
	//String name; should now be included in the constructor

	//create Player list
	private List<Player> players = new ArrayList<Player>();

	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {

		super(id, name);

	}

	public Player addPlayer(String name) {

		//create team local instance
		Player player = null;

		//adding iterator to ensur ewe do not inclure an existing player
		Iterator<Player> playersIterator = players.iterator();

		
		while (playersIterator.hasNext()) {

			//set player var
			Player playerInstance = playersIterator.next();

			//check to make sure we are not adding existing player
			if (playerInstance.getName().equalsIgnoreCase(name)) {

				player = playerInstance;	// this means player is taken

			}

			else {

				// if it is not taken then we can add the player
				players.add(player);
			}
		}

		return player;

	}

	@Override // this overrides the method inherited from entity
	public String toString() {

		return "Team [id=" + super.getId() + ", name=" + super.getName() + "]";

	}
}