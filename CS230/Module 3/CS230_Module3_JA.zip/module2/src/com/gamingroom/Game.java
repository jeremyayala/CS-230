package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity {
	
	//long id; moving to constructor
	//String name; moving to constructor

	// Hid the default constructor and adding private list based on UML
	
	private List<Team> teams = new ArrayList<Team>();

	// Creating constructor with id and name 
	public Game(long id, String name){

		super(id, name);

	}
	
	//Ensuring that we check for existing team before adding
    public Team addTeam(String name) {

        // Existence check 
        Iterator<Team> teamsIterator = teams.iterator();

        while (teamsIterator.hasNext()) {
            Team teamInstance = teamsIterator.next();

            if (teamInstance.getName().equalsIgnoreCase(name)) {
                return teamInstance;
            }
        }

        // Creates new team if it does not exist at all
        Team team = new Team(teams.size() + 1, name);
        teams.add(team);

        return team;
    }

	@Override //overriding the inherited method 
	public String toString() {

		return "Game[id =" + super.getId() + ", name = " + super.getName() + "]";
	}

}
