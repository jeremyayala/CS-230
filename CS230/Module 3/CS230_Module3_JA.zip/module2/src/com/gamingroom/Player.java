package com.gamingroom;

/**
 * A simple class to hold information about a player
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a player is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Player extends Entity{	
	
	
	//long id; added to constructor
	//String name; added to constructor
	
	/*
	 * Constructor change to inherit 
	 */
	public Player(long id, String name) {

		/// using super since we are calling from Entity
		super(id, name);

	}

	/* nreated a new cpnstructor */
	
	public Player(long id, String name, Team team) {

		super(id, name);

	}

	@Override
	public String toString() {
		return "Player [id = " + super.getId() + ", name=" + super.getName() + "]";
	}
}